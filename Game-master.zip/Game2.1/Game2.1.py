# Imports to make the game do stuff
import time
import hashlib
# Main Command Interface
#Main
def main(user, stored_email):
    if user == "Main":
        print("Hello " + stored_email + "! \nWelcome to the Command Line Interface. \nHere you can execute various game commands.\n")
    print("Loading Interface...")
    time.sleep(3)
    print("Program Loaded!\n\n")
    commands()
#commands
def commands():
    usrinput = int(input("Please select a command:\n1 : Check age\n2 : Cryptography\n3 : Sign out"))
    if usrinput == 1:
        imptyp = "Check Age"
        conf(imptyp)
    elif usrinput == 2:
        imptyp = "Cryptography"
        conf(imptyp)
    elif usrinput == 3:
        imptyp = "Signout"
        conf(imptyp)
    else:
        print("Feature not found!\n\n")
        time.sleep(1)
        commands()
#User select
def usrselect():
    print("********** Login System **********")
    print("1.Signup")
    print("2.Login")
    print("3.Proceed as Guest")
    ch = int(input("Select your choice:\n"))
    if ch == 1:
        signup()
    elif ch == 2:
        login()
    elif ch == 3:
        user = "Guest"
        stored_email = "guest"
        main(user, stored_email)
    else:
        print("Wrong Choice!")
        time.sleep(2)
        usrselect()
#Sign up
def signup():
    email = input("Enter username: ")
    pwd = input("Enter password: ")
    conf_pwd = input("Confirm password: ")
    if conf_pwd == pwd:
        enc = conf_pwd.encode()
        hash1 = hashlib.md5(enc).hexdigest()
        with open("credentials.txt", "w") as f:
            f.write(email + "\n")
            f.write(hash1)
        f.close()
        print("You have registered successfully!")
        usrselect()
    else:
        print("Password is not same as above! \n")
        time.sleep(2)
        userselect()
#Login
def login():
    email = input("Enter username: ")
    pwd = input("Enter password: ")
    auth = pwd.encode()
    auth_hash = hashlib.md5(auth).hexdigest()
    with open("credentials.txt", "r") as f:
        stored_email, stored_pwd = f.read().split("\n")
    f.close()
    if email == stored_email and auth_hash == stored_pwd:
        print("Logged in Successfully!")
        user = "Main"
        main(user, stored_email)
    else:
        print("Login failed! \n")
        time.sleep(2)
        usrselect()
# Connectors
#Main Con
def conf(imptyp):
    go = input(str(imptyp)+ " imput detected, confirm?\n(Y or N)\n")
    if go == "Y" or "y":
        proceed = True
        if imptyp == "Check Age":
            age(proceed)
        elif imptyp == "Cryptography":
            crypto(proceed)
        elif imptyp == "Signout":
            usrselect()
    elif go == "N" or "n":
        print("Command Canceled\n")
        time.sleep(1.5)
        commands()
    else:
        print("Invalid Input")
        time.sleep(1.5)
        commands()
# Game Commands
#Age
def age(proceed):
    if proceed == True:
        agenum = int(input("What is your age? \n "))
        if agenum not in range(5, 90):
            print("Not a valid input!\n\n")
            time.sleep(1.5)
            commands()
        elif agenum in range(5, 90):
            checkage(agenum)
        else: 
            print("Error")
            time.sleep(1.5)
            commands()
def checkage(agenum):
        condision = agenum > 18
        condision2 = agenum < 18
        if condision:
            print("You are older than 18 years old\n")
            time.sleep(1)
            commands()
        elif condision2:
            print("You are younger than 18 years old\n")
            time.sleep(1)
            commands()
        else:
            print("You are 18 years old\n")
            time.sleep(1)
            commands()
#Cryptograpghy
def crypto(proceed):
    if proceed == True:
        print("This feature will let you encrypt and decrypt messages using a substitution cipher. It is not done yet but you can use the active features.\n")
        time.sleep(1)
        enctyp = int(input("Select a tool:\n1 : Encryption\n2 : Decryption\n"))
        if enctyp == 1:
            encrypt()
        elif enctyp == 2:
            decrypt()
        else:
            print("Invalid input!\n\n")
            time.sleep(2)
            commands()
def encrypt():
    alphabet = "abcdefghijklmnopqrstuvwxyz"
    key = "fcpevqkzgmtrayonujdlwhbxsi"
    text = input("Write a message to be encrypted:\n")
    print("This is the encrypted text:\n")
    print("".join([key[alphabet.find(a)] if a in alphabet else a for a in text.lower() ]))
    time.sleep(2)
    commands()
def decrypt():
    alphabet ="fcpevqkzgmtrayonujdlwhbxsi"
    key = "abcdefghijklmnopqrstuvwxyz"
    text = input("Write a message to be decrypted:\n")
    print("This is the decrypted text:\n")
    print("".join([key[alphabet.find(a)] if a in alphabet else a for a in text.lower() ]))
    time.sleep(2)
    commands()
# Now to activate the game:
usrselect()
